from .pip_compat import PIP_VERSION, parse_requirements

__all__ = ["PIP_VERSION", "parse_requirements"]
