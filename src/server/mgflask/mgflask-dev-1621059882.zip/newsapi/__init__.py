from newsapi.newsapi_client import NewsApiClient  # noqa
